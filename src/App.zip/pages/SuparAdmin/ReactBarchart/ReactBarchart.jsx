import React from 'react'

const ReactBarchart = () => {
  return (
    <div>
      
    </div>
  )
}

export default ReactBarchart
